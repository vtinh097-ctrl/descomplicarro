<?php
/**
 * DESCOMPLICARRO — funções auxiliares de leitura de conteúdo (uso no front-end).
 *
 * Estas funções são o único ponto de leitura de post meta usado pelos
 * templates. Isso mantém a lógica "buscar valor, aplicar fallback, escapar"
 * em um único lugar em vez de repetida em cada arquivo de template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lê um campo de texto/URL do post atual (ou informado), com fallback.
 * Sempre escapado para uso seguro em atributos/texto simples.
 */
function dc_field( $key, $default = '', $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$value   = get_post_meta( $post_id, $key, true );
	return ( $value !== '' && $value !== null ) ? $value : $default;
}

/** Igual a dc_field(), mas sem escapar — usar apenas dentro de esc_html()/esc_attr() no template. */
function dc_field_raw( $key, $default = '', $post_id = null ) {
	return dc_field( $key, $default, $post_id );
}

/** Campo de texto: imprime já escapado. */
function dc_text( $key, $default = '', $post_id = null ) {
	echo esc_html( dc_field( $key, $default, $post_id ) );
}

/** Campo de parágrafo/textarea: permite quebras de linha simples, escapa o resto. */
function dc_paragraph( $key, $default = '', $post_id = null ) {
	echo wp_kses_post( wpautop( dc_field( $key, $default, $post_id ) ) );
}

/**
 * Imprime um campo de texto de várias linhas como uma sequência de <p>,
 * uma tag por linha não vazia — usado para blocos de parágrafos "corridos"
 * armazenados em um único textarea (ver inc/meta-boxes.php).
 */
function dc_paragraphs_lines( $key, $default_lines, $post_id = null, $class = '' ) {
	$raw   = dc_field_raw( $key, '', $post_id );
	$lines = $raw !== '' ? preg_split( '/\r\n|\r|\n/', trim( $raw ) ) : (array) $default_lines;
	$class_attr = $class ? ' class="' . esc_attr( $class ) . '"' : '';
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( $line === '' ) {
			continue;
		}
		echo '<p' . $class_attr . '>' . esc_html( $line ) . '</p>';
	}
}

/** Campo de URL: imprime já escapado para uso em href. */
function dc_url( $key, $default = '#', $post_id = null ) {
	$value = dc_field( $key, $default, $post_id );
	echo esc_url( $value ? $value : $default );
}

/**
 * Campo de imagem: aceita um ID de anexo (Biblioteca de Mídia) armazenado
 * em post meta e devolve a URL. Se vazio, usa o placeholder do tema.
 */
function dc_image_url( $key, $post_id = null, $fallback_file = 'placeholder-photo.svg' ) {
	$post_id      = $post_id ? $post_id : get_the_ID();
	$attachment_id = (int) get_post_meta( $post_id, $key, true );
	if ( $attachment_id ) {
		$url = wp_get_attachment_image_url( $attachment_id, 'large' );
		if ( $url ) {
			return $url;
		}
	}
	return get_template_directory_uri() . '/assets/images/' . $fallback_file;
}

/**
 * Imprime o conteúdo completo de um espaço publicitário — o
 * <a class="ad-slot__unit">, com tudo dentro. Ponto único usado por TODOS
 * os espaços publicitários do tema (atuais e futuros): qualquer novo
 * .ad-slot deve chamar esta função em vez de repetir o HTML do
 * placeholder, para herdar a mesma lógica de exibição.
 *
 * $key_prefix identifica o par de campos daquele espaço:
 * "{$key_prefix}_imagem" (ID de anexo) e "{$key_prefix}_url" (link do
 * anunciante) — ex.: dc_ad_slot_unit('dc_home_ad1').
 *
 * Regras:
 * - Imagem cadastrada → exibe a imagem (proporção original preservada,
 *   sem corte) no lugar do texto placeholder; a etiqueta "Publicidade"
 *   permanece visível sobre a imagem.
 * - Sem imagem → mantém o placeholder original ("PUBLICIDADE — ESPAÇO
 *   RESERVADO"), exatamente como sempre foi.
 * - Link do anunciante vazio → usa "#" (mesmo placeholder de link já
 *   usado no restante do projeto), nunca uma URL inventada.
 */
function dc_ad_slot_unit( $key_prefix ) {
	$post_id   = get_the_ID();
	$image_id  = (int) get_post_meta( $post_id, "{$key_prefix}_imagem", true );
	$image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : false;
	$href      = dc_field( "{$key_prefix}_url", '#', $post_id );
	$href      = $href ? $href : '#';

	$classes = 'ad-slot__unit' . ( $image_url ? ' ad-slot__unit--filled' : '' );
	echo '<a href="' . esc_url( $href ) . '" class="' . esc_attr( $classes ) . '">';

	if ( $image_url ) {
		echo '<span class="ad-slot__eyebrow">Publicidade</span>';
		echo '<img src="' . esc_url( $image_url ) . '" alt="Publicidade" class="ad-slot__image">';
	} else {
		echo '<span class="ad-slot__frame-mark ad-slot__frame-mark--tl" aria-hidden="true"></span>';
		echo '<span class="ad-slot__eyebrow">Publicidade</span>';
		echo '<span class="ad-slot__placeholder-text">PUBLICIDADE — ESPAÇO RESERVADO</span>';
		echo '<span class="ad-slot__frame-mark ad-slot__frame-mark--br" aria-hidden="true"></span>';
	}

	echo '</a>';
}

/** Verifica se uma seção opcional está ativa (padrão: ativa, quando o campo nunca foi salvo). */
function dc_section_active( $key, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$value   = get_post_meta( $post_id, $key, true );
	return $value === '' ? true : (bool) $value;
}

/**
 * Lê um repetidor (lista de itens) salvo como array associativo em post meta.
 * Retorna sempre um array (nunca null), para uso direto em foreach.
 */
function dc_repeater( $key, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$value   = get_post_meta( $post_id, $key, true );
	return is_array( $value ) ? $value : array();
}

/**
 * Lê um campo de LEGENDA DE IMAGEM. Diferente de dc_field(), distingue um
 * campo que nunca foi salvo (usa o texto padrão da V1) de um campo que o
 * administrador esvaziou de propósito (metadata_exists() continua
 * verdadeiro — a linha existe no banco com valor '' — e a ausência de
 * legenda passa a ser permanente, sem o padrão reaparecer).
 * Ver inc/meta-boxes.php: os campos de legenda são sempre gravados no
 * save, mesmo vazios, em vez de apagados — é isso que preserva o registro
 * de "esvaziado intencionalmente".
 */
function dc_caption( $key, $default = '', $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( ! metadata_exists( 'post', $post_id, $key ) ) {
		return $default;
	}
	return get_post_meta( $post_id, $key, true );
}

/**
 * Imprime a tag da legenda apenas quando há texto a exibir. Quando o campo
 * foi esvaziado intencionalmente (ou uma legenda de repetidor está vazia),
 * nada é impresso — nem a tag/o espaço reservado.
 */
function dc_caption_html( $key, $default = '', $class = 'figure-caption', $post_id = null ) {
	$value = dc_caption( $key, $default, $post_id );
	if ( $value === '' ) {
		return;
	}
	echo '<p class="' . esc_attr( $class ) . '">' . esc_html( $value ) . '</p>';
}

/** Mesma regra "vazio = nada" para a legenda de um item de repetidor (galerias). */
function dc_caption_html_raw( $value, $class = 'figure-caption' ) {
	$value = trim( (string) $value );
	if ( $value === '' ) {
		return;
	}
	echo '<p class="' . esc_attr( $class ) . '">' . esc_html( $value ) . '</p>';
}

/**
 * CONFIGURAÇÕES GLOBAIS — lê um valor da página de opções "Configurações
 * Descomplicarro" (option_name: dc_options). Ver inc/options-page.php.
 */
function dc_option( $key, $default = '' ) {
	$options = get_option( 'dc_options', array() );
	return ( isset( $options[ $key ] ) && $options[ $key ] !== '' ) ? $options[ $key ] : $default;
}

/**
 * Monta um link do WhatsApp (wa.me) a partir do número cadastrado em
 * Configurações Descomplicarro + uma mensagem pré-preenchida específica.
 *
 * Enquanto o número oficial não for cadastrado no painel, o link aponta
 * para um placeholder claramente identificado (WHATSAPP_DESCOMPLICARRO),
 * nunca para um número inventado.
 */
function dc_whatsapp_link( $message = '' ) {
	$numero = dc_option( 'whatsapp', '' );
	$numero = $numero !== '' ? preg_replace( '/[^0-9]/', '', $numero ) : 'WHATSAPP_DESCOMPLICARRO';
	$url    = 'https://wa.me/' . $numero;
	if ( $message !== '' ) {
		$url .= '?text=' . rawurlencode( $message );
	}
	return $url;
}

/** Monta o mailto: do e-mail oficial cadastrado, ou o placeholder enquanto não houver e-mail definido. */
function dc_email_link() {
	$email = dc_option( 'email', '' );
	return 'mailto:' . ( $email !== '' ? $email : 'EMAIL_DESCOMPLICARRO' );
}

/** Devolve o valor a exibir para o e-mail/whatsapp quando usados como texto visível (não apenas link). */
function dc_option_or_pending( $key, $label_pendente ) {
	$value = dc_option( $key, '' );
	return $value !== '' ? $value : $label_pendente;
}

/** As 27 UFs — lista fixa usada no filtro público do GI CONECTA e no cadastro de oficinas no admin. */
function dc_uf_list() {
	return array(
		'AC' => 'Acre', 'AL' => 'Alagoas', 'AP' => 'Amapá', 'AM' => 'Amazonas', 'BA' => 'Bahia',
		'CE' => 'Ceará', 'DF' => 'Distrito Federal', 'ES' => 'Espírito Santo', 'GO' => 'Goiás',
		'MA' => 'Maranhão', 'MT' => 'Mato Grosso', 'MS' => 'Mato Grosso do Sul', 'MG' => 'Minas Gerais',
		'PA' => 'Pará', 'PB' => 'Paraíba', 'PR' => 'Paraná', 'PE' => 'Pernambuco', 'PI' => 'Piauí',
		'RJ' => 'Rio de Janeiro', 'RN' => 'Rio Grande do Norte', 'RS' => 'Rio Grande do Sul',
		'RO' => 'Rondônia', 'RR' => 'Roraima', 'SC' => 'Santa Catarina', 'SP' => 'São Paulo',
		'SE' => 'Sergipe', 'TO' => 'Tocantins',
	);
}

/**
 * GI CONECTA — URL do formulário de credenciamento de oficinas. Fonte única
 * usada tanto pelo botão em Para Motoristas quanto pelo botão do rodapé, para
 * nunca haver dois links divergentes. Enquanto não houver valor cadastrado em
 * Configurações Descomplicarro, usa o formulário oficial já fornecido.
 */
function dc_oficinas_credenciamento_url() {
	return dc_option( 'oficinas_credenciamento_url', 'https://docs.google.com/forms/d/e/1FAIpQLSc04iO7lDkTZ5SHdMk4xUrM5P6-tRbeY2TUxggV_waTUWVtLQ/viewform' );
}

/**
 * GI CONECTA — a página Para Oficinas está temporariamente fora do ar
 * (reformulação) enquanto este valor não for marcado em Configurações
 * Descomplicarro. Nada é apagado: reativar é só marcar a caixa e salvar,
 * sem editar nenhum arquivo.
 */
function dc_oficinas_pagina_ativa() {
	return (int) dc_option( 'oficinas_pagina_ativa', 0 ) === 1;
}

/** Imprime uma lista <ul><li> a partir de um campo de texto com uma linha por item (serviços, especialidades). */
function dc_list_lines( $key, $post_id = null, $class = '' ) {
	$raw   = dc_field_raw( $key, '', $post_id );
	$lines = $raw !== '' ? preg_split( '/\r\n|\r|\n/', trim( $raw ) ) : array();
	if ( ! $lines ) {
		return;
	}
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( $line === '' ) {
			continue;
		}
		echo '<li>' . esc_html( $line ) . '</li>';
	}
	echo '</ul>';
}

/**
 * INTEGRAÇÃO EDITORIAL — as cinco editorias oficiais do Em Foco (slug da
 * categoria nativa do WordPress => rótulo/assinatura exibidos no site).
 * Ponto único de referência usado por template-em-foco.php e category.php,
 * para nunca haver divergência entre o texto exibido em cada lugar.
 */
function dc_emfoco_categorias() {
	return array(
		'noticias'   => array( 'label' => 'Notícias', 'assinatura' => 'O que está acontecendo.' ),
		'reviews'    => array( 'label' => 'Reviews', 'assinatura' => 'O que testamos e analisamos.' ),
		'guias'      => array( 'label' => 'Guias', 'assinatura' => 'O que você precisa entender para decidir.' ),
		'tecnica'    => array( 'label' => 'Técnica', 'assinatura' => 'Como funciona, como diagnosticar e como reparar.' ),
		'bastidores' => array( 'label' => 'Bastidores', 'assinatura' => 'Quem, como e onde o setor acontece.' ),
	);
}

/**
 * Imprime um cartão .emfoco-card para uma publicação real do WordPress —
 * usado na capa do Em Foco, nas páginas de editoria e nos "Conteúdos
 * relacionados" da matéria individual, para nunca duplicar o HTML do
 * cartão em cada template.
 */
function dc_emfoco_card( $post, $extra_class = '', $on_dark = false ) {
	$categorias = get_the_category( $post->ID );
	$categoria  = ! empty( $categorias ) ? $categorias[0]->name : '';
	$thumb      = get_the_post_thumbnail_url( $post, 'large' );
	if ( ! $thumb ) {
		$thumb = get_template_directory_uri() . '/assets/images/placeholder-photo.svg';
	}
	$classes      = 'emfoco-card' . ( $extra_class ? ' ' . $extra_class : '' );
	$date_classes = 'emfoco-card__date' . ( $on_dark ? ' emfoco-card__date--on-dark' : '' );
	?>
	<a href="<?php echo esc_url( get_permalink( $post ) ); ?>" class="<?php echo esc_attr( $classes ); ?>">
		<div class="emfoco-card__media">
			<img src="<?php echo esc_url( $thumb ); ?>" alt="" class="emfoco-card__image">
		</div>
		<?php if ( $categoria ) : ?>
			<span class="emfoco-card__category"><?php echo esc_html( $categoria ); ?></span>
		<?php endif; ?>
		<h3 class="emfoco-card__title"><?php echo esc_html( get_the_title( $post ) ); ?></h3>
		<span class="<?php echo esc_attr( $date_classes ); ?>"><?php echo esc_html( get_the_date( '', $post ) ); ?></span>
	</a>
	<?php
}
